#ifndef GENERAL_H
#define GENERAL_H
#include <ctime>
#include <string>
#include <vector>
#include<iostream>
using namespace std;
class Date;
class Time;
int getDetails(vector<string> &arr);
int daysInYear(int year, int month, int day);
bool Leap(int year);
int MonthDays(int year, int month);
int isValidDate(string date, Date *&ptr);

int checkAddress(string address, vector<string> &, bool flag = true);
class Time {
public:
	int hour, minute;
	Time(int hour, int minute);
	Time();
	bool operator>(const Time &other);
	bool operator==(const Time &other);
	int operator-(const Time &other);
	friend ostream &operator<<(ostream &os, const Time &time);
	bool operator>=(const Time &other);
	~Time();
	
};

class Date {
public:
	int year, month, day;

	Date(int year, int month, int day);
	Date(); 

	bool operator>=(const Date &other);
	bool operator<=(const Date &other);
	bool operator>(const Date &other);
	bool operator<(const Date &other);
	bool operator==(const Date &other);
	Date operator++(int);
	int operator-(const Date& other) const;
	friend ostream &operator<<(ostream &os, const Date &date);
};

class Venue;
class Program;

class Congregations {
public:
  static vector<Congregations *> congregates;
	static int searchCongregation(string name, Congregations *&ptr);
  Congregations(string name, Date startDate, Date endDate);
	virtual ~Congregations();

	
	virtual int addProgram(string programType, string programName, Date startDate, Date endDate);
	int deleteProgram(Program *prog);
	int showPrograms();
	int searchProgram(string progName, Program *&prog);

	int showReserved();

	vector<Program *> programs;
  string type;
  string name;
  Date startDate, endDate;
};

class Conference :  public Congregations {
public:
	string type;
	Conference(string name, Date startDate, Date endDate);
	int addProgram(string programType, string programName, Date startDate, Date endDate);
};

class Games :  public Congregations {
public:
	Games(string name, Date startDate, Date endDate);
	int addProgram(string programType, string programName, Date startDate, Date endDate);
};

class Concerts :  public Congregations {
public:
	Concerts(string name, Date startDate, Date endDate);
	int addProgram(string programType, string programName, Date startDate, Date endDate);
};

class Convention :  public Congregations {
public:
	Convention(string name, Date startDate, Date endDate);
	int addProgram(string programType, string programName, Date startDate, Date endDate);
};
class Program {
public:
  Date startDate, endDate;
  Congregations *congregation;
	vector<Venue *> venues;
  string name, type;

  Program(Date start, Date end, Congregations *congregation, string name, string type);
	~Program();

	int showReserved();
};
class Venue {
public:
  static vector<Venue *> venues;
  static int showVenues(vector<string> &location, string opt = "");
  static int searchVenue(string ven, string country, Venue *&ptr);

  Venue(string venueName, string country, vector<string> location, int capacity);
	virtual ~Venue();

  int checkReservation(Date startDate, Date endDate);
	virtual int checkProgram(string progType) = 0;

	
  int reserveVenue(Program *prog);
  int freeVenue(Program *prog);
  string name;
  string country;
	string type;
  vector<string> location;
  int capacity;
	vector<Program *> programs;
	friend ostream &operator<<(ostream &os, const Venue &ven);
};
class Stadium : public Venue {
public:
	Stadium(string venueName, string country, vector<string> location, int capacity);
	virtual ~Stadium();
	virtual int checkProgram(string progType) = 0;
};
class Outdoor_stadium : public Stadium {
public:	Outdoor_stadium(string venueName, string country, vector<string> location, int capacity);

	int checkProgram(string progType);
};
class Indoor_stadium : public Stadium {
public:
	Indoor_stadium(string venueName, string country, vector<string> location, int capacity);
	int checkProgram(string progType);
};
class Swimming_pool : public Stadium {
public:
	Swimming_pool(string venueName, string country, vector<string> location, int capacity);
	int checkProgram(string progType);
};
class Hotel : public Venue {
public:
	Hotel(string venueName, string country, vector<string> location, int capacity);
	int checkProgram(string progType);
};
class Convention_centre : public Venue {
public:
	Convention_centre(string venueName, string country, vector<string> location, int capacity);
	int checkProgram(string progType);
};
class Concert_hall : public Venue {
public:
	Concert_hall(string venueName, string country, vector<string> location, int capacity);
	int checkProgram(string progType);
};
#endif



