#include <iomanip>
#include "general.hpp"
#include <iostream>
using namespace std;
void handle_error()
{
	cout << "-1\nError" << endl;
}
int verify(int idx, vector<string> &detailsList)
{
	for (int pos = idx; pos < 8; ++pos)
	{
		if (!detailsList[pos].empty())
		{
			return -1;
		}
	}
	return 0;
}
Time::Time()
{
	this->hour = 0;
	this->minute = 0;
}
Time::Time(int hour, int minute)
{
	this->hour = hour;
	this->minute = minute;
}
bool Time::operator==(const Time &secondobj)
{
	bool ans = this->hour == secondobj.hour && this->minute == secondobj.minute;
	return ans;
}

int Time::operator-(const Time &secondobj)
{
	bool ans = ((this->hour - secondobj.hour) * 60) + this->minute - secondobj.minute;
	return ans;
}
bool Time::operator>(const Time &secondobj)
{
	bool ans = (this->hour > secondobj.hour || this->minute > secondobj.minute);
	return ans;
}

bool Time::operator>=(const Time &secondobj)
{
	bool ans = (this->hour > secondobj.hour || (this->hour == secondobj.hour && this->minute >= secondobj.minute));
	return ans;
}
ostream &operator<<(ostream &out, const Time &time)
{

	if (time.hour < 10)
		out << '0';
	out << time.hour << ':';
	if (time.minute < 10)
		out << '0';
	out << time.minute;
	return out;
}
Date::Date()
{
	this->day = 0;
	this->month = 0;
	this->year = 0;
}
Date::Date(int year, int month, int day)
{
	this->day = day;
	this->month = month;
	this->year = year;
}
bool Date::operator>=(const Date &secondobj)
{
	if (this->year > secondobj.year)
		return true;
	else if (this->year < secondobj.year)
		return false;
	if (this->month > secondobj.month)
		return true;
	else if (this->month < secondobj.month)
		return false;
	if (this->day >= secondobj.day)
		return true;
	else
		return false;
}
bool Date::operator<=(const Date &secondobj)
{
	if (this->year < secondobj.year)
		return true;
	else if (this->year > secondobj.year)
		return false;
	if (this->month < secondobj.month)
		return true;
	else if (this->month > secondobj.month)
		return false;
	if (this->day <= secondobj.day)
		return true;
	else
		return false;
}

bool Date::operator>(const Date &secondobj)
{
	if (this->year > secondobj.year)
		return true;
	else if (this->year < secondobj.year)
		return false;

	if (this->month > secondobj.month)
		return true;
	else if (this->month < secondobj.month)
		return false;

	if (this->day > secondobj.day)
		return true;
	else
		return false;
}

bool Date::operator<(const Date &secondobj)
{
	if (this->year < secondobj.year)
		return true;
	else if (this->year > secondobj.year)
		return false;

	if (this->month < secondobj.month)
		return true;
	else if (this->month > secondobj.month)
		return false;

	if (this->day < secondobj.day)
		return true;
	else
		return false;
}
bool Date::operator==(const Date &secondobj)
{
	return this->year == secondobj.year && this->day == secondobj.day && this->month == secondobj.month;
}
Date Date::operator++(int)
{
	Date t = *this;
	day++;
	if (day > MonthDays(year, month))
	{
		day = 1;
		month++;
		if (month > 12)
		{
			month = 1;
			year++;
		}
	}

	return t;
}
int Date::operator-(const Date &secondobj) const
{
	return abs(daysInYear(year, month, day) - daysInYear(secondobj.year, secondobj.month, secondobj.day));
}
ostream &operator<<(ostream &os, const Date &date)
{

	os << (date.year < 1000 ? "0" : "") << (date.year < 100 ? "0" : "")
	   << (date.year < 10 ? "0" : "") << date.year << '-';

	if (date.month < 10)
		os << '0';
	os << date.month << '-';

	if (date.day < 10)
		os << '0';
	os << date.day;

	return os;
}

int getDetails(vector<string> &details)
{
	string input, word;
	for (int i = 0; i < 20; i++)
	{
	}
	details.assign(8, "");
	getline(cin, input);
	bool f = false, Isword = false,
		 Isnum = false;
	int count = 0;
	for (int y = 0; y < (int)input.length(); y++)
	{
		char x = input[y];
		if (((x != ' ' && x != '\t') || Isword) && count < 8)
		{
			if (x == '\"')
			{
				if (f || Isnum)
					return -1;

				if (Isword)
				{
					Isword = false;
					details[count++] = word;
					word = "";
				}
				else
				{
					Isword = true;
					word += "\"";
				}
			}
			else
			{
				if (Isnum && (x < '0' || x > '9'))
				{
					return -1;
				}
				else if (Isnum == false)
				{
					if ((x >= '0' && x <= '9') && Isword == false && f == false)
					{
						Isnum = true;
					}
					else if (Isword == false)
						f = true;
				}
				word += x;
			}
		}
		else if (x == ' ' || x == '\t')
		{
			if (Isnum)
			{
				details[count++] = word;
				word = "";
				Isnum = false;
			}
			else if (f)
			{
				details[count++] = word;
				word = "";
				f = false;
			}
		}
		else if (count >= 8)
			return -1;
	}

	if (word != "")
		details[count++] = word;

	return 0;
}

int daysInYear(int year, int month, int day)
{
	int days = day;
	for (int y = 0; y < year; ++y)
	{
		days += (Leap(y) ? 366 : 365);
	}
	for (int m = 1; m < month; ++m)
	{
		days += MonthDays(year, m);
	}
	return days;
}

bool Leap(int year)
{
	return (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
}

int MonthDays(int year, int month)
{
	switch (month)
	{
	case 2:
		return (Leap(year)) ? 29 : 28;
	case 4:
	case 6:
	case 9:
	case 11:
		return 30;
	default:
		return 31;
	}
}

int isValidDate(string date, Date *&ptr)
{

	string year = "", month = "", day = "";

	if (date.length() != 10)
		return -1;

	for (int i = 0; i < 4; i++)
	{
		if (date[i] < '0' || date[i] > '9')
			return -1;
		year += date[i];
	}

	if (date[4] != '-')
		return -1;

	for (int i = 5; i < 7; i++)
	{
		if (date[i] < '0' || date[i] > '9')
			return -1;
		month += date[i];
	}

	if (date[7] != '-')
		return -1;

	for (int i = 8; i < 10; i++)
	{
		if (date[i] < '0' || date[i] > '9')
			return -1;
		day += date[i];
	}

	int yearInt = stoi(year), monthInt = stoi(month), dayInt = stoi(day);

	if (monthInt <= 0 || monthInt > 12 || dayInt <= 0 || dayInt > MonthDays(yearInt, monthInt))
		return -1;

	if (yearInt <= 2024 && monthInt <= 9 && dayInt <= 17)
		return -1;

	ptr = new Date(yearInt, monthInt, dayInt);

	return 0;
}
int checkAddress(string address, vector<string> &a, bool f)
{
	vector<string> details(5);
	string curr;
	int count = 0;

	if (!f)
	{
		count++;
	}

	for (char c : address)
	{
		if (c != ':')
		{
			curr += c;
		}
		else
		{
			if (count < 5)
			{
				details[count] = curr;
				curr.clear();
				count++;
			}
			else
			{
				return -1;
			}
		}
	}

	if (count < 5)
	{
		details[count] = curr;
		count++;
	}
	if (count != 5)
		return -1;
	a = details;
	return 0;
}

Program::Program(Date startDate, Date endDate, Congregations *congregation, string name, string type) : startDate{startDate}, endDate{endDate}, congregation{congregation}, name{name}, type{type}
{

	congregation->programs.push_back(this);
	this->venues = {};
}

Program::~Program()
{

	while (!this->venues.empty())
	{
		this->venues[0]->freeVenue(this);
	}
}

int Program::showReserved()
{

	cout << this->venues.size() << endl;
	for (auto ven : this->venues)
	{
		cout << *ven << endl;
	}

	return 0;
}
vector<Venue *> Venue::venues = {};

int Venue::showVenues(vector<string> &location, string x)
{
	int numOfVen = 0;
	string out = "";
	bool flag = x.empty();

	if (flag)
	{
		for (auto ven : Venue::venues)
		{
			bool locationMatch =
				(location[0].empty() || location[0] == ven->location[0]) &&
				(location[1].empty() || location[1] == ven->location[1]) &&
				(location[2].empty() || location[2] == ven->location[2]) &&
				(location[3].empty() || location[3] == ven->location[3]) &&
				(location[4].empty() || location[4] == ven->location[4]);

			bool typeMatch = flag || (ven->type == x);

			if (locationMatch && typeMatch)
			{
				out += ven->name + " " + ven->location[0] + ":" + ven->location[1] + ":" + ven->location[2] + ":" + ven->location[3] + ":" + ven->location[4] + " " + ven->type + " " + to_string(ven->capacity) + "\n";
				numOfVen++;
			}
		}
	}
	else
	{
		for (auto ven : Venue::venues)
		{
			bool locationMatch =
				(location[0].empty() || location[0] == ven->location[0]) &&
				(location[1].empty() || location[1] == ven->location[1]) &&
				(location[2].empty() || location[2] == ven->location[2]) &&
				(location[3].empty() || location[3] == ven->location[3]) &&
				(location[4].empty() || location[4] == ven->location[4]);

			bool typeMatch = flag || (ven->type == x);

			if (locationMatch && typeMatch)
			{
				out += ven->name + " " + ven->location[0] + ":" + ven->location[1] + ":" + ven->location[2] + ":" + ven->location[3] + ":" + ven->location[4] + " " + ven->type + " " + to_string(ven->capacity) + "\n";
				numOfVen++;
			}
		}
	}

	cout << numOfVen << endl
		 << out;

	return 0;
}

int Venue::searchVenue(string ven, string country, Venue *&ptr)
{
	for (auto venue : Venue::venues)
	{
		if (venue->name == ven && venue->country == country)
		{
			ptr = venue;
			return 0;
		}
	}

	return -1;
}

Venue::Venue(string venueName, string country, vector<string> location, int capacity)
{
	this->name = venueName;
	this->country = country;
	this->capacity = capacity;
	this->location.assign(location.begin(), location.end());
	Venue::venues.push_back(this);
}

Venue::~Venue()
{
}

int Venue::checkReservation(Date startDate, Date endDate)
{

	for (auto program : this->programs)
		if (startDate <= program->endDate && endDate >= program->startDate)
			return -1;

	return 0;
}

int Venue::reserveVenue(Program *program)
{

	if (this->programs.empty())
	{
		this->programs.push_back(program);
	}
	else
	{
		int i = 0;
		for (i = 0; i < this->programs.size(); i++)
		{
			if (this->programs[i]->startDate > program->endDate)
			{
				this->programs.insert(this->programs.begin() + i, program);
				break;
			}
		}

		if (i == this->programs.size())
		{
			this->programs.push_back(program);
		}
	}

	program->venues.push_back(this);

	return 0;
}

int Venue::freeVenue(Program *program)
{

	int index = 0;
	for (auto i : this->programs)
	{
		if (i == program)
			break;
		index++;
	}

	if (index == (int)this->programs.size())
	{
		return -1;
	}

	this->programs.erase(this->programs.begin() + index);

	index = 0;
	for (auto ven : program->venues)
	{
		if (ven == this)
			break;
		index++;
	}
	program->venues.erase(program->venues.begin() + index);

	return 0;
}

ostream &operator<<(ostream &os, const Venue &ven)
{
	string out = ven.name + " " + ven.location[0] + ":" + ven.location[1] + ":" + ven.location[2] + ":" + ven.location[3] + ":" + ven.location[4] + " " + ven.type + " " + to_string(ven.capacity);
	os << out;
	return os;
}

Stadium::Stadium(string venueName, string country, vector<string> location, int capacity) : Venue(venueName, country, location, capacity) {}

Stadium::~Stadium()
{
}

Outdoor_stadium::Outdoor_stadium(string venueName, string country, vector<string> location, int capacity) : Stadium(venueName, country, location, capacity)
{
	this->type = "Outdoor Stadium";
};

int Outdoor_stadium::checkProgram(string progType)
{
	return 0;
}

Indoor_stadium::Indoor_stadium(string venueName, string country, vector<string> location, int capacity) : Stadium(venueName, country, location, capacity)
{
	this->type = "Indoor Stadium";
};

int Indoor_stadium::checkProgram(string progType)
{
	return 0;
}

Swimming_pool::Swimming_pool(string venueName, string country, vector<string> location, int capacity) : Stadium(venueName, country, location, capacity)
{
	this->type = "Swimming Pool";
};

int Swimming_pool::checkProgram(string progType)
{
	return 0;
}

Hotel::Hotel(string venueName, string country, vector<string> location, int capacity) : Venue(venueName, country, location, capacity)
{
	this->type = "Hotel";
};

int Hotel::checkProgram(string progType)
{
	return 0;
}

Convention_centre::Convention_centre(string venueName, string country, vector<string> location, int capacity) : Venue(venueName, country, location, capacity)
{
	this->type = "Convention Centre";
};

int Convention_centre::checkProgram(string progType)
{
	return 0;
}

Concert_hall::Concert_hall(string venueName, string country, vector<string> location, int capacity) : Venue(venueName, country, location, capacity)
{
	this->type = "Concert Hall";
};

int Concert_hall::checkProgram(string progType)
{
	return 0;
}
vector<Congregations *> Congregations::congregates = {};

int Congregations::searchCongregation(string name, Congregations *&ptr)
{

	for (auto congregation : Congregations::congregates)
	{
		if (congregation->name == name)
		{
			ptr = congregation;
			return 0;
		}
	}

	return -1;
}

Congregations::Congregations(string name, Date startDate, Date endDate) : name{name}, startDate{startDate}, endDate{endDate}
{
	this->programs = {};

	Congregations::congregates.push_back(this);
}

Congregations::~Congregations()
{

	int index = 0;
	for (auto cong1 : Congregations::congregates)
	{
		if (cong1 == this)
			break;
		index++;
	}
	Congregations::congregates.erase(Congregations::congregates.begin() + index);

	while (!this->programs.empty())
	{
		delete this->programs[this->programs.size() - 1];
		this->programs.pop_back();
	}
}

int Congregations::addProgram(string programType, string programName, Date startDate, Date endDate)
{

	for (auto program : this->programs)
	{
		if (programName == program->name)
			return -1;
	}

	Program *newProgram = new Program(startDate, endDate, this, programName, programType);

	this->programs.push_back(newProgram);

	return 0;
}

int Congregations::deleteProgram(Program *program)
{

	if (!program->venues.empty())
		return -1;

	for (int i = 0; i < this->programs.size(); i++)
	{
		if (program == this->programs[i])
		{
			this->programs.erase(this->programs.begin() + i);
			break;
		}
	}

	delete program;
	return 0;
}

int Congregations::showPrograms()
{

	cout << this->programs.size() << endl;
	for (auto program : this->programs)
	{
		cout << program->type << ' ' << program->name << ' ' << program->startDate << ' ' << program->endDate << endl;
	}

	return 0;
}

int Congregations::searchProgram(string progName, Program *&program)
{

	for (auto i : this->programs)
	{
		if (progName == i->name)
		{
			program = i;
			return 0;
		}
	}

	return -1;
}

int Congregations::showReserved()
{

	cout << this->programs.size() << endl;
	for (auto program : this->programs)
	{
		cout << program->name << ' ' << program->type << ' ';
		program->showReserved();
	}

	return 0;
}

Conference::Conference(string name, Date startDate, Date endDate) : Congregations(name, startDate, endDate)
{
	this->type = "Conference";
}

int Conference::addProgram(string programType, string programName, Date startDate, Date endDate)
{

	if (programType != "Workshop" || programType != "Main Conference" || programType != "Banquet")
		return -1;

	Congregations::addProgram(programType, programName, startDate, endDate);
	return 0;
}

Games::Games(string name, Date startDate, Date endDate) : Congregations(name, startDate, endDate)
{
	this->type = "Games";
}

int Games::addProgram(string progType, string progName, Date startDate, Date endDate)
{

	if (progType != "Ceremony" || progType != "Track and field" || progType != "Indoor games" || progType != "Water sports")
		return -1;

	Congregations::addProgram(progType, progName, startDate, endDate);
	return 0;
}

Concerts::Concerts(string name, Date startDate, Date endDate) : Congregations(name, startDate, endDate)
{
	this->type = "Concert";
}

int Concerts::addProgram(string progType, string progName, Date startDate, Date endDate)
{

	if (progType != "Pre-concert" || progType != "Main Concert")
		return -1;

	Congregations::addProgram(progType, progName, startDate, endDate);
	return 0;
}

Convention::Convention(string name, Date startDate, Date endDate) : Congregations(name, startDate, endDate)
{
	this->type = "Convention";
}

int Convention::addProgram(string progType, string progName, Date startDate, Date endDate)
{

	if (progType != "Food Court" || progType != "Exhibition")
		return -1;

	Congregations::addProgram(progType, progName, startDate, endDate);
	return 0;
}
int main()
{

	vector<string> details(8);
	int x;
	bool f;
	while (true)
	{
		f = true;
		x = getDetails(details);
		if (x != 0)
		{
			handle_error();
			continue;
		}
		else if (details[0] == "addCongregation")
		{
			bool f = false;
			for (int i = 1; i < 5; i++)
			{
				if (details[i].empty() || details[i][0] != '\"')
				{
					f = true;
					break;
				}
				details[i].erase(0, 1);
			}
			if (f || verify(5, details) == -1)
			{
				handle_error();
				continue;
			}
			Date *startDate = nullptr, *endDate = nullptr;
			if (isValidDate(details[3], startDate) != 0 || isValidDate(details[4], endDate) != 0 || *startDate > *endDate)
			{
				handle_error();
				continue;
			}
			if (details[2] == "Conference")
				new Conference(details[1], *startDate, *endDate);
			else if (details[2] == "Games")
				new Games(details[1], *startDate, *endDate);
			else if (details[2] == "Concert")
				new Concerts(details[1], *startDate, *endDate);
			else if (details[2] == "Convention")
				new Convention(details[1], *startDate, *endDate);
			else
			{
				handle_error();
				continue;
			}
			cout << 0 << endl;	
		}
		else if (details[0] == "deleteCongregation")
		{

			if (details[1].empty() || details[1][0] != '\"' || verify(2, details) == -1)
			{
				handle_error();
				continue;
			}

			details[1].erase(0, 1);
			Congregations *congregation;
			if (Congregations::searchCongregation(details[1], congregation) != 0)
			{
				handle_error();
				continue;
			}

			delete congregation;
			cout << 0 << endl;
		}
		else if (details[0] == "showCongregations")
		{

			if (verify(1, details) == -1)
			{
				handle_error();
				continue;
			}

			cout << Congregations::congregates.size() << endl;
			for (auto congregation : Congregations::congregates)
			{
				cout << congregation->name << ' ' << congregation->type << ' ' << congregation->startDate << ' ' << congregation->endDate << endl;
			}
		}
		else if (details[0] == "addProgram")
		{

			bool f = false;
			for (int i = 1; i < 6; i++)
			{
				if (details[i].empty() || details[i][0] != '\"')
				{
					f = true;
					break;
				}

				details[i].erase(0, 1);
			}

			Congregations *congregation;
			Date *startDate, *endDate;
			Program *program;
			if (f || verify(6, details) != 0 || Congregations::searchCongregation(details[1], congregation) != 0 || congregation->searchProgram(details[3], program) == 0 || isValidDate(details[4], startDate) != 0 || isValidDate(details[5], endDate) != 0 || *startDate > *endDate || *startDate < congregation->startDate || congregation->endDate < *endDate)
			{
				handle_error();
				continue;
			}
			new Program(*startDate, *endDate, congregation, details[3], details[2]);
			cout << 0 << endl;	
		}
		else if (details[0] == "deleteProgram")
		{

			if (details[1].empty() || details[1][0] != '\"' || details[2].empty() || details[2][0] != '\"')
			{
				handle_error();
				continue;
			}
			details[1].erase(0, 1);
			details[2].erase(0, 1);

			Congregations *congregation;
			Program *program;
			if (verify(3, details) != 0 || Congregations::searchCongregation(details[1], congregation) != 0 || congregation->searchProgram(details[2], program))
			{
				handle_error();
				continue;
			}
			int k = 0;
			for (auto i : congregation->programs)
			{
				if (i == program)
				{
					break;
				}
				k++;
			}
			if (!program->venues.empty())
			{
				handle_error();
				continue;
			}
			congregation->programs.erase(congregation->programs.begin() + k);
			delete program;
			cout << 0 << endl;
		}
		else if (details[0] == "showPrograms")
		{
			if (details[1].empty() || details[1][0] != '\"')
			{
				handle_error();
				continue;
			}
			details[1].erase(0, 1);

			Congregations *congregation;
			if (verify(2, details) != 0 || Congregations::searchCongregation(details[1], congregation) != 0)
			{
				handle_error();
				continue;
			}
			congregation->showPrograms();
		}
		else if (details[0] == "addVenue")
		{

			if (details[1].empty() || details[1][0] != '\"' || details[2].empty() || details[2][0] != '\"' || details[3].empty() || details[3][0] != '\"' || details[4].empty() || details[4][0] < '0' || details[4][0] > '9')
			{
				handle_error();
				continue;
			}

			f = true;
			for (int i = 0; i < (int)details[4].length(); i++)
				if (details[4][i] < '0' || details[4][i] > '9')
				{
					handle_error();
					f = false;
					break;
				}

			if (!f)
			{
				continue;
			}
			for (int i = 1; i < 4; i++)
				details[i].erase(0, 1);
			vector<string> location(5, "");
			if (checkAddress(details[2], location) != 0)
			{
				handle_error();
				continue;
			}

			for (auto add : location)
			{
				if (add.empty())
				{
					f = false;
					handle_error();
					break;
				}
			}
			if (!f)
				continue;

			int cap = stoi(details[4]);

			if (details[3] == "Outdoor Stadium")
				new Outdoor_stadium(details[1], location[4], location, cap);

			else if (details[3] == "Hotel")
				new Hotel(details[1], location[4], location, cap);
			else if (details[3] == "Convention Centre")

				new Convention_centre(details[1], location[4], location, cap);
			else if (details[3] == "Indoor Stadium")
				new Indoor_stadium(details[1], location[4], location, cap);
			else if (details[3] == "Swimming Pool")
				new Swimming_pool(details[1], location[4], location, cap);
			else if (details[3] == "Concert Hall")
				new Concert_hall(details[1], location[4], location, cap);
			else
				f = false;

			if (f)
				cout << "0" << endl;
			else
				handle_error();
		}
		else if (details[0] == "showVenues")
		{

			if (details[1].empty() || details[1][0] != '\"' || verify(3, details) == -1)
			{
				handle_error();
				continue;
			}

			bool x = !details[3].empty();
			if (x && details[3][0] != '\"')
			{
				handle_error();
				continue;
			}

			details[3].erase(0, 1);

			if (f)
			{

				details[1].erase(0, 1);
				vector<string> location(5, "");
				if (checkAddress(details[1], location, (bool)false) != 0)
				{
					handle_error();
					continue;
				}

				if (!x)
				{
					if (Venue::showVenues(location) != 0)
					{
						handle_error();
						continue;
					}
				}
				else
				{
					if (Venue::showVenues(location, details[3]))
					{
						handle_error();
						continue;
					}
				}
			}
		}
		else if (details[0] == "deleteVenue")
		{

			if (details[1].empty() || details[1][0] != '\"' || details[2].empty() || details[2][0] != '\"')
			{
				handle_error();
				continue;
			}
			else
			{
				if (verify(3, details) != 0)
				{
					handle_error();
					continue;
				}
			}
			for (int i = 1; i < 3; i++)
				details[i].erase(0, 1);
			Venue *ven;
			if (Venue::searchVenue(details[1], details[2], ven) != 0 || !ven->programs.empty())
			{
				handle_error();
				continue;
			}

			int i;
			for (i = 0; i < (int)Venue::venues.size(); i++)
			{
				if (ven == Venue::venues[i])
					break;
			}
			Venue::venues.erase(Venue::venues.begin() + i);

			delete ven;

			cout << "0" << endl;
		}
		else if (details[0] == "reserveVenue")
		{

			if (details[1].empty() || details[1][0] != '\"' || details[2].empty() || details[2][0] != '\"' || details[3].empty() || details[3][0] != '\"' || details[4].empty() || details[4][0] != '\"' || verify(5, details) != 0)
			{
				handle_error();
				continue;
			}
			for (int i = 1; i < 5; i++)
				details[i].erase(0, 1);
			Congregations *congregation;
			Venue *ven;
			Program *program;
			if (Congregations::searchCongregation(details[3], congregation) != 0 || Venue::searchVenue(details[1], details[2], ven) != 0 || congregation->searchProgram(details[4], program) != 0 || ven->checkReservation(program->startDate, program->endDate) != 0 || ven->reserveVenue(program) != 0)
			{
				handle_error();
				continue;
			}
			else
				cout << 0 << endl;
		}
		else if (details[0] == "freeVenue")
		{

			if (details[1].empty() || details[1][0] != '\"' || details[2].empty() || details[2][0] != '\"' || details[3].empty() || details[3][0] != '\"' || details[4].empty() || details[4][0] != '\"' || verify(5, details) != 0)
			{
				handle_error();
				continue;
			}
			for (int i = 1; i < 5; i++)
				details[i].erase(0, 1);
			Congregations *congregation;
			Venue *ven;
			Program *program;
			if (Congregations::searchCongregation(details[3], congregation) != 0 || Venue::searchVenue(details[1], details[2], ven) != 0 || congregation->searchProgram(details[4], program) != 0 || ven->freeVenue(program) != 0)
			{
				handle_error();
				continue;
			}
			else
				cout << 0 << endl;
		}
		else if (details[0] == "showReserved")
		{

			if (details[1].empty() || details[1][0] != '\"' || verify(4, details) != 0)
			{
				handle_error();
				continue;
			}

			Congregations *congregation;
			details[1].erase(0, 1);
			if (Congregations::searchCongregation(details[1], congregation) != 0 || congregation->showReserved() != 0)
			{
				handle_error();
				continue;
			}
		}
		else if (details[0] == "End")
			return 0;
		else
		{
			handle_error();
		}
	}
}
